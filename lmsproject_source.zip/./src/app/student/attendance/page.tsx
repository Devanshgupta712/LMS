'use client';

export default function StudentAttendancePage() {
    const daysInMonth = Array.from({ length: 28 }, (_, i) => i + 1);
    const presentDays = new Set([1, 2, 3, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 19, 20]);

    const downloadCSV = () => {
        const rows = [['Date', 'Status']];
        daysInMonth.forEach(day => {
            const dateStr = `2026-02-${day.toString().padStart(2, '0')}`;
            rows.push([dateStr, presentDays.has(day) ? 'Present' : 'Absent']);
        });
        const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", "my_attendance_feb_2026.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="animate-in">
            <div className="page-header">
                <div>
                    <h1 className="page-title">My Attendance</h1>
                    <p className="page-subtitle">Track your attendance record</p>
                </div>
                <button className="btn btn-primary" onClick={downloadCSV}>
                    📥 Download CSV
                </button>
            </div>

            <div className="grid-4 mb-24">
                <div className="stat-card primary"><div className="stat-icon primary">✅</div><div className="stat-info"><h3>Present</h3><div className="stat-value">{presentDays.size}</div></div></div>
                <div className="stat-card danger"><div className="stat-icon danger">❌</div><div className="stat-info"><h3>Absent</h3><div className="stat-value">{daysInMonth.length - presentDays.size}</div></div></div>
                <div className="stat-card success"><div className="stat-icon success">📊</div><div className="stat-info"><h3>Percentage</h3><div className="stat-value">{Math.round((presentDays.size / daysInMonth.length) * 100)}%</div></div></div>
                <div className="stat-card accent"><div className="stat-icon accent">📅</div><div className="stat-info"><h3>Working Days</h3><div className="stat-value">{daysInMonth.length}</div></div></div>
            </div>

            <div className="card">
                <h3 className="font-semibold mb-16">February 2026</h3>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7, 1fr)', gap: '8px' }}>
                    {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map(d => (
                        <div key={d} style={{ textAlign: 'center', fontSize: '12px', color: '#64748b', padding: '8px' }}>{d}</div>
                    ))}
                    {daysInMonth.map(day => (
                        <div key={day} style={{
                            textAlign: 'center', padding: '12px 8px', borderRadius: '8px', fontSize: '14px', fontWeight: 500,
                            background: presentDays.has(day) ? 'rgba(74, 222, 128, 0.15)' : 'rgba(248, 113, 113, 0.1)',
                            color: presentDays.has(day) ? '#4ade80' : '#f87171',
                            border: `1px solid ${presentDays.has(day) ? 'rgba(74, 222, 128, 0.2)' : 'rgba(248, 113, 113, 0.15)'}`,
                        }}>{day}</div>
                    ))}
                </div>
            </div>
        </div>
    );
}
