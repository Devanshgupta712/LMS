'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { getStoredUser } from '@/lib/api';

const portals = [
  {
    title: 'Admin Portal',
    subtitle: 'Manage courses, batches, students & settings',
    href: '/login/admin',
    icon: '🛡️',
    gradient: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
    glow: 'rgba(99,102,241,0.15)',
    border: 'rgba(99,102,241,0.2)',
  },
  {
    title: 'Trainer Portal',
    subtitle: 'Manage attendance, projects, tasks & feedback',
    href: '/login/trainer',
    icon: '📋',
    gradient: 'linear-gradient(135deg, #10b981, #06b6d4)',
    glow: 'rgba(16,185,129,0.15)',
    border: 'rgba(16,185,129,0.2)',
  },
  {
    title: 'Marketing Portal',
    subtitle: 'Track leads, campaigns & conversions',
    href: '/login/marketing',
    icon: '📈',
    gradient: 'linear-gradient(135deg, #f59e0b, #f97316)',
    glow: 'rgba(245,158,11,0.15)',
    border: 'rgba(245,158,11,0.2)',
  },
  {
    title: 'Student Portal',
    subtitle: 'Access courses, attend classes & apply for jobs',
    href: '/login/student',
    icon: '🎓',
    gradient: 'linear-gradient(135deg, #06b6d4, #3b82f6)',
    glow: 'rgba(6,182,212,0.15)',
    border: 'rgba(6,182,212,0.2)',
  },
];

export default function PortalSelector() {
  const router = useRouter();

  useEffect(() => {
    const user = getStoredUser();
    if (user) {
      switch (user.role) {
        case 'SUPER_ADMIN':
        case 'ADMIN':
          router.push('/dashboard');
          break;
        case 'TRAINER':
          router.push('/training/attendance');
          break;
        case 'MARKETER':
          router.push('/marketing/leads');
          break;
        case 'STUDENT':
          router.push('/student/courses');
          break;
        default:
          break;
      }
    }
  }, [router]);

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #0a0a14 0%, #111827 50%, #0a0a14 100%)', padding: '40px 20px' }}>
      <div style={{ maxWidth: '960px', width: '100%' }}>
        {/* Header */}
        <div style={{ textAlign: 'center', marginBottom: '48px' }}>
          <div style={{
            width: '80px', height: '80px', borderRadius: '22px',
            background: 'linear-gradient(135deg, #6366f1, #8b5cf6)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            margin: '0 auto 20px', fontSize: '36px',
            boxShadow: '0 12px 32px rgba(99,102,241,0.3)',
          }}>A</div>
          <h1 style={{ color: '#f1f5f9', fontSize: '32px', fontWeight: 800, margin: '0 0 8px', letterSpacing: '-0.02em' }}>
            Apptech Careers
          </h1>
          <p style={{ color: '#64748b', fontSize: '16px', margin: 0, fontWeight: 400 }}>
            Learning Management System — Select your portal to sign in
          </p>
        </div>

        {/* Portal Cards Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px' }}>
          {portals.map((portal) => (
            <a key={portal.href} href={portal.href} style={{ textDecoration: 'none' }}>
              <div style={{
                background: 'rgba(30,33,48,0.6)', backdropFilter: 'blur(16px)',
                border: `1px solid ${portal.border}`, borderRadius: '20px',
                padding: '32px 24px', textAlign: 'center',
                cursor: 'pointer', transition: 'all 0.3s ease',
                position: 'relative', overflow: 'hidden',
              }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(-6px)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = `0 20px 50px rgba(0,0,0,0.4), 0 0 30px ${portal.glow}`;
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLDivElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLDivElement).style.boxShadow = 'none';
                }}
              >
                <div style={{
                  width: '56px', height: '56px', borderRadius: '16px',
                  background: portal.gradient,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  margin: '0 auto 16px', fontSize: '26px',
                  boxShadow: `0 8px 20px ${portal.glow}`,
                }}>
                  {portal.icon}
                </div>
                <h3 style={{ color: '#f1f5f9', fontSize: '18px', fontWeight: 700, margin: '0 0 6px' }}>{portal.title}</h3>
                <p style={{ color: '#94a3b8', fontSize: '13px', margin: 0, lineHeight: 1.5 }}>{portal.subtitle}</p>
              </div>
            </a>
          ))}
        </div>

        {/* Footer */}
        <div style={{ textAlign: 'center', marginTop: '40px', color: '#475569', fontSize: '13px' }}>
          © 2026 Apptech Careers LMS. All rights reserved.
        </div>
      </div>
    </div>
  );
}
