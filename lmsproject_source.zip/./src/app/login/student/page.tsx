'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { setToken, setStoredUser } from '@/lib/api';

export default function StudentLoginPage() {
    const router = useRouter();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');
        setLoading(true);
        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password }),
            });
            if (!res.ok) {
                const data = await res.json();
                setError(data.detail || 'Invalid credentials');
                setLoading(false);
                return;
            }
            const data = await res.json();
            if (data.user.role !== 'STUDENT') {
                setError('Access denied. This portal is for Students only.');
                setLoading(false);
                return;
            }
            setToken(data.access_token);
            setStoredUser(data.user);
            router.push('/student/courses');
        } catch (err: any) {
            console.error('Login error:', err);
            setError(`Connection error: ${err.message || 'Unknown error'}`);
            setLoading(false);
        }
    };

    return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #001a1f 0%, #164e63 50%, #00161c 100%)' }}>
            <div style={{ width: '100%', maxWidth: '440px', padding: '20px' }}>
                <div style={{ background: 'rgba(6,182,212,0.06)', backdropFilter: 'blur(24px)', border: '1px solid rgba(6,182,212,0.15)', borderRadius: '24px', padding: '48px 40px', boxShadow: '0 25px 60px rgba(0,0,0,0.5), 0 0 40px rgba(6,182,212,0.08)' }}>

                    <div style={{ textAlign: 'center', marginBottom: '36px' }}>
                        <div style={{ width: '64px', height: '64px', borderRadius: '18px', background: 'linear-gradient(135deg, #06b6d4, #3b82f6)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', fontSize: '28px', boxShadow: '0 8px 24px rgba(6,182,212,0.35)' }}>🎓</div>
                        <h1 style={{ color: '#e2e8f0', fontSize: '24px', fontWeight: 700, margin: '0 0 4px' }}>Student Portal</h1>
                        <p style={{ color: '#94a3b8', fontSize: '14px', margin: 0 }}>Apptech Careers — Learning Hub</p>
                    </div>

                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '18px' }}>
                        {error && (
                            <div style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '12px', padding: '12px', color: '#f87171', fontSize: '14px', textAlign: 'center' }}>{error}</div>
                        )}
                        <div>
                            <label style={{ color: '#67e8f9', fontSize: '13px', fontWeight: 600, display: 'block', marginBottom: '6px' }}>Email Address</label>
                            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="student@email.com" required
                                style={{ width: '100%', padding: '13px 16px', borderRadius: '12px', border: '1px solid rgba(6,182,212,0.2)', background: 'rgba(6,182,212,0.06)', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                        </div>
                        <div>
                            <label style={{ color: '#67e8f9', fontSize: '13px', fontWeight: 600, display: 'block', marginBottom: '6px' }}>Password</label>
                            <div style={{ position: 'relative' }}>
                                <input type={showPassword ? "text" : "password"} value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required
                                    style={{ width: '100%', padding: '13px 40px 13px 16px', borderRadius: '12px', border: '1px solid rgba(6,182,212,0.2)', background: 'rgba(6,182,212,0.06)', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                                <button type="button" onClick={() => setShowPassword(!showPassword)}
                                    style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: '#64748b', cursor: 'pointer', padding: '4px' }}>
                                    {showPassword ? '👁️' : '👁️‍🗨️'}
                                </button>
                            </div>
                        </div>
                        <button type="submit" disabled={loading} style={{
                            width: '100%', padding: '14px', borderRadius: '12px', border: 'none',
                            background: 'linear-gradient(135deg, #06b6d4, #3b82f6)', color: '#fff',
                            fontSize: '15px', fontWeight: 600, cursor: loading ? 'wait' : 'pointer',
                            marginTop: '4px', opacity: loading ? 0.7 : 1, boxShadow: '0 4px 16px rgba(6,182,212,0.3)',
                        }}>
                            {loading ? 'Signing in...' : 'Sign In →'}
                        </button>
                    </form>


                    <div style={{ textAlign: 'center', marginTop: '20px' }}>
                        <a href="/register" style={{ color: '#67e8f9', fontSize: '13px', textDecoration: 'none', fontWeight: 500 }}>Don&apos;t have an account? Register here</a>
                        <span style={{ color: '#334155', margin: '0 10px' }}>|</span>
                        <a href="/" style={{ color: '#64748b', fontSize: '13px', textDecoration: 'none' }}>Portal Selection</a>
                    </div>
                </div>
            </div>
        </div>
    );
}
