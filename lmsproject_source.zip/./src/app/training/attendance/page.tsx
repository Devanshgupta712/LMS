'use client';

import { useState, useEffect } from 'react';
import { apiGet, apiPost } from '@/lib/api';

interface Batch { id: string; name: string; course_name: string; }
interface Student { id: string; name: string; student_id: string | null; }
interface AttendanceRecord { id: string; student_id: string; student_name: string; student_sid: string | null; batch_id: string; date: string; status: string; }

export default function AttendancePage() {
    const [batches, setBatches] = useState<Batch[]>([]);
    const [selectedBatch, setSelectedBatch] = useState('');
    const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
    const [records, setRecords] = useState<AttendanceRecord[]>([]);
    const [students, setStudents] = useState<Student[]>([]);
    const [localStatus, setLocalStatus] = useState<Record<string, string>>({});
    const [loading, setLoading] = useState(false);
    const [leaveModal, setLeaveModal] = useState<{ studentId: string; studentName: string } | null>(null);
    const [leaveForm, setLeaveForm] = useState({ start_date: '', end_date: '', reason: '' });
    const [leaveMsg, setLeaveMsg] = useState('');

    useEffect(() => { apiGet('/api/admin/batches').then(setBatches).catch(() => { }); }, []);

    useEffect(() => {
        if (selectedBatch && selectedDate) {
            setLoading(true);
            apiGet(`/api/training/attendance?batch_id=${selectedBatch}&date=${selectedDate}`)
                .then(data => { setRecords(data); const map: Record<string, string> = {}; data.forEach((r: AttendanceRecord) => { map[r.student_id] = r.status; }); setLocalStatus(map); })
                .catch(() => { })
                .finally(() => setLoading(false));
            apiGet('/api/admin/students').then(setStudents).catch(() => { });
        }
    }, [selectedBatch, selectedDate]);

    const handleSave = async () => {
        const recs = Object.entries(localStatus).map(([student_id, status]) => ({
            student_id, batch_id: selectedBatch, date: selectedDate, status,
        }));
        if (recs.length > 0) {
            await apiPost('/api/training/attendance', { records: recs });
            alert('Attendance saved!');
        }
    };

    const downloadCSV = () => {
        if (!selectedBatch || students.length === 0) return;
        const batchName = batches.find(b => b.id === selectedBatch)?.name || 'Batch';

        const rows = [['Student ID', 'Name', 'Status', 'Date']];
        students.forEach(s => {
            const status = localStatus[s.id] || 'ABSENT';
            rows.push([s.student_id || '-', s.name, status, selectedDate]);
        });

        const csvContent = "data:text/csv;charset=utf-8," + rows.map(e => e.join(",")).join("\n");
        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `${batchName.replace(/\\s+/g, '_')}_Attendance_${selectedDate}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const cycleStatus = (studentId: string, currentStatus: string) => {
        const order = ['PRESENT', 'ABSENT', 'LATE', 'LEAVE'];
        const next = order[(order.indexOf(currentStatus) + 1) % order.length];
        setLocalStatus(prev => ({ ...prev, [studentId]: next }));
    };

    const markAll = (status: string) => {
        const map: Record<string, string> = {};
        students.forEach(s => { map[s.id] = status; });
        setLocalStatus(map);
    };

    const openLeaveModal = (studentId: string, studentName: string) => {
        setLeaveModal({ studentId, studentName });
        setLeaveForm({ start_date: selectedDate, end_date: selectedDate, reason: '' });
        setLeaveMsg('');
    };

    const submitLeave = async () => {
        if (!leaveModal) return;
        try {
            await apiPost('/api/training/leave-request', {
                user_id: leaveModal.studentId,
                start_date: leaveForm.start_date,
                end_date: leaveForm.end_date,
                reason: leaveForm.reason,
            });
            setLeaveMsg('Leave request created successfully!');
            setLocalStatus(prev => ({ ...prev, [leaveModal.studentId]: 'LEAVE' }));
            setTimeout(() => setLeaveModal(null), 1200);
        } catch {
            setLeaveMsg('Failed to create leave request.');
        }
    };

    const statusConfig: Record<string, { color: string; icon: string; btnClass: string }> = {
        PRESENT: { color: '#4ade80', icon: '✅', btnClass: 'btn-success' },
        ABSENT: { color: '#f87171', icon: '❌', btnClass: 'btn-danger' },
        LATE: { color: '#fbbf24', icon: '⏰', btnClass: 'btn-warning' },
        LEAVE: { color: '#a78bfa', icon: '🗓️', btnClass: 'btn-accent' },
    };

    const presentCount = Object.values(localStatus).filter(s => s === 'PRESENT').length;
    const absentCount = Object.values(localStatus).filter(s => s === 'ABSENT').length;
    const lateCount = Object.values(localStatus).filter(s => s === 'LATE').length;
    const leaveCount = Object.values(localStatus).filter(s => s === 'LEAVE').length;

    return (
        <div className="animate-in">
            <div className="page-header">
                <div><h1 className="page-title">Attendance</h1><p className="page-subtitle">Mark daily attendance by batch</p></div>
                <div style={{ display: 'flex', gap: '10px' }}>
                    <button className="btn btn-ghost" onClick={downloadCSV} disabled={!selectedBatch || students.length === 0}>
                        📥 Download CSV
                    </button>
                    <button className="btn btn-primary" onClick={handleSave}>
                        💾 Save Attendance
                    </button>
                </div>
            </div>

            {/* Filters Row */}
            <div style={{ display: 'flex', gap: '12px', marginBottom: '20px', flexWrap: 'wrap', alignItems: 'center' }}>
                <select className="form-input" style={{ maxWidth: '280px' }} value={selectedBatch} onChange={e => setSelectedBatch(e.target.value)}>
                    <option value="">Select Batch</option>
                    {batches.map(b => <option key={b.id} value={b.id}>{b.name} ({b.course_name})</option>)}
                </select>
                <input className="form-input" type="date" style={{ maxWidth: '180px' }} value={selectedDate} onChange={e => setSelectedDate(e.target.value)} />
                <div style={{ display: 'flex', gap: '6px' }}>
                    <button className="btn btn-sm btn-success" onClick={() => markAll('PRESENT')}>✅ All Present</button>
                    <button className="btn btn-sm btn-danger" onClick={() => markAll('ABSENT')}>❌ All Absent</button>
                </div>
            </div>

            {/* Summary Stats */}
            {selectedBatch && students.length > 0 && (
                <div className="grid-4 mb-24">
                    <div className="stat-card success"><div className="stat-icon success">✅</div><div className="stat-info"><h3>Present</h3><div className="stat-value">{presentCount}</div></div></div>
                    <div className="stat-card danger"><div className="stat-icon danger">❌</div><div className="stat-info"><h3>Absent</h3><div className="stat-value">{absentCount}</div></div></div>
                    <div className="stat-card accent"><div className="stat-icon accent">⏰</div><div className="stat-info"><h3>Late</h3><div className="stat-value">{lateCount}</div></div></div>
                    <div className="stat-card primary"><div className="stat-icon primary">🗓️</div><div className="stat-info"><h3>On Leave</h3><div className="stat-value">{leaveCount}</div></div></div>
                </div>
            )}

            {/* Table */}
            <div className="card">
                {!selectedBatch ? (
                    <div className="empty-state"><div className="empty-icon">✅</div><h3>Select a batch and date</h3><p className="text-sm text-muted">Choose a batch above to start marking attendance.</p></div>
                ) : loading ? <p>Loading...</p> : students.length === 0 ? (
                    <div className="empty-state"><div className="empty-icon">👥</div><h3>No students found</h3></div>
                ) : (
                    <div className="table-responsive"><table className="table">
                        <thead><tr><th>Student ID</th><th>Name</th><th>Status</th><th>Actions</th></tr></thead>
                        <tbody>{students.map(s => {
                            const st = localStatus[s.id] || 'ABSENT';
                            const cfg = statusConfig[st] || statusConfig['ABSENT'];
                            return (
                                <tr key={s.id}>
                                    <td style={{ fontFamily: 'monospace', color: '#a5b4fc' }}>{s.student_id || '-'}</td>
                                    <td><strong>{s.name}</strong></td>
                                    <td>
                                        <button onClick={() => cycleStatus(s.id, st)} className={`btn btn-sm ${cfg.btnClass}`}
                                            style={{ minWidth: '120px', justifyContent: 'center' }}>
                                            {cfg.icon} {st}
                                        </button>
                                    </td>
                                    <td>
                                        <button className="btn btn-sm btn-ghost" onClick={() => openLeaveModal(s.id, s.name)}
                                            title="Apply Leave">🗓️ Leave</button>
                                    </td>
                                </tr>
                            );
                        })}</tbody>
                    </table></div>
                )}
            </div>

            {/* Leave Modal */}
            {leaveModal && (
                <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1000, backdropFilter: 'blur(4px)' }}
                    onClick={() => setLeaveModal(null)}>
                    <div style={{ background: '#1a1a2e', borderRadius: '20px', padding: '32px', maxWidth: '440px', width: '100%', border: '1px solid rgba(255,255,255,0.1)' }}
                        onClick={e => e.stopPropagation()}>
                        <h3 style={{ margin: '0 0 4px', fontSize: '18px', color: '#e2e8f0' }}>Apply Leave — {leaveModal.studentName}</h3>
                        <p style={{ margin: '0 0 20px', color: '#64748b', fontSize: '13px' }}>Create a leave request for this student</p>

                        {leaveMsg && (
                            <div style={{
                                padding: '10px 14px', borderRadius: '10px', marginBottom: '16px', fontSize: '13px',
                                background: leaveMsg.includes('success') ? 'rgba(74,222,128,0.12)' : 'rgba(248,113,113,0.12)',
                                color: leaveMsg.includes('success') ? '#4ade80' : '#f87171',
                                border: `1px solid ${leaveMsg.includes('success') ? 'rgba(74,222,128,0.3)' : 'rgba(248,113,113,0.3)'}`
                            }}>
                                {leaveMsg}
                            </div>
                        )}

                        <div style={{ display: 'flex', flexDirection: 'column', gap: '14px' }}>
                            <div>
                                <label style={{ display: 'block', fontSize: '13px', color: '#94a3b8', marginBottom: '6px' }}>Start Date</label>
                                <input className="form-input" type="date" value={leaveForm.start_date}
                                    onChange={e => setLeaveForm(prev => ({ ...prev, start_date: e.target.value }))} />
                            </div>
                            <div>
                                <label style={{ display: 'block', fontSize: '13px', color: '#94a3b8', marginBottom: '6px' }}>End Date</label>
                                <input className="form-input" type="date" value={leaveForm.end_date}
                                    onChange={e => setLeaveForm(prev => ({ ...prev, end_date: e.target.value }))} />
                            </div>
                            <div>
                                <label style={{ display: 'block', fontSize: '13px', color: '#94a3b8', marginBottom: '6px' }}>Reason</label>
                                <textarea className="form-input" rows={3} placeholder="Reason for leave..."
                                    value={leaveForm.reason} onChange={e => setLeaveForm(prev => ({ ...prev, reason: e.target.value }))} />
                            </div>
                            <div style={{ display: 'flex', gap: '10px', marginTop: '8px' }}>
                                <button className="btn btn-primary" onClick={submitLeave} style={{ flex: 1 }}>Submit Leave Request</button>
                                <button className="btn btn-ghost" onClick={() => setLeaveModal(null)}>Cancel</button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
