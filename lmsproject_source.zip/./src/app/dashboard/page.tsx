'use client';

import { useState, useEffect } from 'react';
import { apiGet } from '@/lib/api';
import { getStoredUser } from '@/lib/api';

export default function DashboardPage() {
    const [user, setUser] = useState<any>(null);
    const [stats, setStats] = useState<any>(null);

    useEffect(() => {
        const u = getStoredUser();
        setUser(u);
        if (u) {
            if (u.role === 'STUDENT') {
                window.location.href = '/student/courses';
                return;
            }
            if (u.role === 'SUPER_ADMIN' || u.role === 'ADMIN') {
                apiGet('/api/admin/dashboard').then(setStats).catch(() => { });
            }
        }
    }, []);

    const role = user?.role || 'STUDENT';
    const name = user?.name || 'User';

    return (
        <div className="animate-in">
            <div className="page-header">
                <div>
                    <h1 className="page-title">Welcome back, {name.split(' ')[0]} 👋</h1>
                    <p className="page-subtitle">Here&apos;s what&apos;s happening today at Apptech Careers</p>
                </div>
            </div>

            {/* Stats Grid */}
            <div className="grid-4 mb-24">
                {role === 'SUPER_ADMIN' || role === 'ADMIN' ? (
                    <>
                        <div className="stat-card primary">
                            <div className="stat-icon primary">🎓</div>
                            <div className="stat-info">
                                <h3>Total Students</h3>
                                <div className="stat-value">{stats?.total_students || 0}</div>
                            </div>
                        </div>
                        <div className="stat-card accent">
                            <div className="stat-icon accent">📚</div>
                            <div className="stat-info">
                                <h3>Active Courses</h3>
                                <div className="stat-value">{stats?.total_courses || 0}</div>
                            </div>
                        </div>
                        <div className="stat-card success">
                            <div className="stat-icon success">👥</div>
                            <div className="stat-info">
                                <h3>Batches</h3>
                                <div className="stat-value">{stats?.total_batches || 0}</div>
                            </div>
                        </div>
                        <div className="stat-card danger">
                            <div className="stat-icon danger">🎯</div>
                            <div className="stat-info">
                                <h3>Active Leads</h3>
                                <div className="stat-value">{stats?.total_leads || 0}</div>
                            </div>
                        </div>
                    </>
                ) : role === 'TRAINER' ? (
                    <>
                        <div className="stat-card primary">
                            <div className="stat-icon primary">👥</div>
                            <div className="stat-info">
                                <h3>My Batches</h3>
                                <div className="stat-value">0</div>
                            </div>
                        </div>
                        <div className="stat-card accent">
                            <div className="stat-icon accent">✅</div>
                            <div className="stat-info">
                                <h3>Today&apos;s Attendance</h3>
                                <div className="stat-value">0%</div>
                            </div>
                        </div>
                        <div className="stat-card success">
                            <div className="stat-icon success">🏗️</div>
                            <div className="stat-info">
                                <h3>Active Projects</h3>
                                <div className="stat-value">0</div>
                            </div>
                        </div>
                        <div className="stat-card danger">
                            <div className="stat-icon danger">⚠️</div>
                            <div className="stat-info">
                                <h3>Pending Tasks</h3>
                                <div className="stat-value">0</div>
                            </div>
                        </div>
                    </>
                ) : (
                    <>
                        <div className="stat-card primary">
                            <div className="stat-icon primary">📚</div>
                            <div className="stat-info">
                                <h3>My Courses</h3>
                                <div className="stat-value">0</div>
                            </div>
                        </div>
                        <div className="stat-card accent">
                            <div className="stat-icon accent">✅</div>
                            <div className="stat-info">
                                <h3>Attendance</h3>
                                <div className="stat-value">0%</div>
                            </div>
                        </div>
                        <div className="stat-card success">
                            <div className="stat-icon success">📝</div>
                            <div className="stat-info">
                                <h3>Tasks Done</h3>
                                <div className="stat-value">0</div>
                            </div>
                        </div>
                        <div className="stat-card danger">
                            <div className="stat-icon danger">⏰</div>
                            <div className="stat-info">
                                <h3>Pending</h3>
                                <div className="stat-value">0</div>
                            </div>
                        </div>
                    </>
                )}
            </div>

            {/* Quick Actions + Recent */}
            <div className="grid-2">
                <div className="card">
                    <h3 className="font-semibold mb-16">Quick Actions</h3>
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                        {(role === 'SUPER_ADMIN' || role === 'ADMIN') && (
                            <>
                                <a href="/admin/courses" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">📚</span>
                                    <span>Manage Courses</span>
                                </a>
                                <a href="/admin/batches" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">👥</span>
                                    <span>Manage Batches</span>
                                </a>
                                <a href="/admin/students" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">🎓</span>
                                    <span>Manage Students</span>
                                </a>
                                <a href="/marketing/leads" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">🎯</span>
                                    <span>Manage Leads</span>
                                </a>
                            </>
                        )}
                        {role === 'TRAINER' && (
                            <>
                                <a href="/training/attendance" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">✅</span>
                                    <span>Mark Attendance</span>
                                </a>
                                <a href="/training/projects" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">🏗️</span>
                                    <span>Manage Projects</span>
                                </a>
                            </>
                        )}
                        {role === 'STUDENT' && (
                            <>
                                <a href="/placement/jobs" className="sidebar-link" style={{ borderRadius: '8px' }}>
                                    <span className="link-icon">💼</span>
                                    <span>Browse Jobs</span>
                                </a>
                            </>
                        )}
                    </div>
                </div>

                <div className="card">
                    <h3 className="font-semibold mb-16">Recent Activity</h3>
                    <div className="empty-state" style={{ padding: '40px 16px' }}>
                        <div className="empty-icon">📋</div>
                        <p className="text-sm text-muted">No recent activity yet. Start by creating courses and batches.</p>
                    </div>
                </div>
            </div>
        </div>
    );
}
