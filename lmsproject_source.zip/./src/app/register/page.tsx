'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function RegisterPage() {
    const router = useRouter();
    const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirmPassword: '', course: '' });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [success, setSuccess] = useState(false);
    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);

    const courses = [
        'Full Stack Web Development',
        'Data Science & AI',
        'Digital Marketing',
    ];

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (form.password !== form.confirmPassword) {
            setError('Passwords do not match');
            return;
        }
        if (form.password.length < 6) {
            setError('Password must be at least 6 characters');
            return;
        }

        setLoading(true);
        try {
            const res = await fetch('/api/auth/register', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: form.name,
                    email: form.email,
                    phone: form.phone || null,
                    password: form.password,
                    role: 'STUDENT',
                    course: form.course || null,
                }),
            });
            const data = await res.json();
            if (!res.ok) {
                setError(data.detail || 'Registration failed');
                return;
            }
            setSuccess(true);
        } catch {
            setError('Network error. Please try again.');
        } finally {
            setLoading(false);
        }
    };

    const set = (key: string, val: string) => setForm(prev => ({ ...prev, [key]: val }));

    if (success) {
        return (
            <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)' }}>
                <div style={{ textAlign: 'center', maxWidth: '460px', padding: '48px 32px' }}>
                    <div style={{ fontSize: '72px', marginBottom: '24px' }}>🎉</div>
                    <h1 style={{ fontSize: '28px', fontWeight: 700, marginBottom: '12px', color: '#e2e8f0' }}>Registration Successful!</h1>
                    <p style={{ color: '#94a3b8', lineHeight: '1.6', marginBottom: '32px' }}>
                        Your account has been created. You can now login with your credentials to access the student portal.
                    </p>
                    <button onClick={() => router.push('/login/student')} style={{
                        padding: '14px 40px', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', color: '#fff',
                        border: 'none', borderRadius: '12px', fontSize: '16px', fontWeight: 600, cursor: 'pointer',
                    }}>
                        Go to Login →
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg, #0f0f1a 0%, #1a1a2e 50%, #16213e 100%)' }}>
            <div style={{ width: '100%', maxWidth: '520px', padding: '40px', margin: '20px' }}>
                {/* Header */}
                <div style={{ textAlign: 'center', marginBottom: '32px' }}>
                    <div style={{ width: '56px', height: '56px', borderRadius: '16px', background: 'linear-gradient(135deg, #6366f1, #8b5cf6)', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 16px', fontSize: '24px' }}>🎓</div>
                    <h1 style={{ fontSize: '26px', fontWeight: 700, color: '#e2e8f0', margin: '0 0 6px' }}>Create Your Account</h1>
                    <p style={{ color: '#94a3b8', fontSize: '14px', margin: 0 }}>Join Apptech Careers and start your learning journey</p>
                </div>

                {/* Form Card */}
                <div style={{
                    background: 'rgba(255,255,255,0.04)', borderRadius: '20px', padding: '32px',
                    border: '1px solid rgba(255,255,255,0.08)', backdropFilter: 'blur(20px)',
                }}>
                    {error && (
                        <div style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: '12px', padding: '12px 16px', color: '#f87171', fontSize: '14px', marginBottom: '20px' }}>
                            {error}
                        </div>
                    )}

                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                        <div>
                            <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: '#94a3b8', marginBottom: '6px' }}>Full Name *</label>
                            <input required value={form.name} onChange={e => set('name', e.target.value)} placeholder="Enter your full name"
                                style={{ width: '100%', padding: '12px 16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '10px', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                        </div>

                        <div>
                            <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: '#94a3b8', marginBottom: '6px' }}>Email Address *</label>
                            <input required type="email" value={form.email} onChange={e => set('email', e.target.value)} placeholder="your@email.com"
                                style={{ width: '100%', padding: '12px 16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '10px', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                        </div>

                        <div>
                            <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: '#94a3b8', marginBottom: '6px' }}>Phone Number</label>
                            <input value={form.phone} onChange={e => set('phone', e.target.value)} placeholder="9876543210"
                                style={{ width: '100%', padding: '12px 16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '10px', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                        </div>

                        <div>
                            <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: '#94a3b8', marginBottom: '6px' }}>Interested Course</label>
                            <select value={form.course} onChange={e => set('course', e.target.value)}
                                style={{ width: '100%', padding: '12px 16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '10px', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }}>
                                <option value="">Select a course (optional)</option>
                                {courses.map(c => <option key={c} value={c}>{c}</option>)}
                            </select>
                        </div>

                        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '12px' }}>
                            <div>
                                <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: '#94a3b8', marginBottom: '6px' }}>Password *</label>
                                <div style={{ position: 'relative' }}>
                                    <input required type={showPassword ? "text" : "password"} value={form.password} onChange={e => set('password', e.target.value)} placeholder="Min 6 characters"
                                        style={{ width: '100%', padding: '12px 40px 12px 16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '10px', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                                    <button type="button" onClick={() => setShowPassword(!showPassword)}
                                        style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '4px' }}>
                                        {showPassword ? '👁️' : '👁️‍🗨️'}
                                    </button>
                                </div>
                            </div>
                            <div>
                                <label style={{ display: 'block', fontSize: '13px', fontWeight: 500, color: '#94a3b8', marginBottom: '6px' }}>Confirm *</label>
                                <div style={{ position: 'relative' }}>
                                    <input required type={showConfirmPassword ? "text" : "password"} value={form.confirmPassword} onChange={e => set('confirmPassword', e.target.value)} placeholder="Re-enter password"
                                        style={{ width: '100%', padding: '12px 40px 12px 16px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: '10px', color: '#e2e8f0', fontSize: '14px', outline: 'none', boxSizing: 'border-box' }} />
                                    <button type="button" onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                        style={{ position: 'absolute', right: '12px', top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', color: '#94a3b8', cursor: 'pointer', padding: '4px' }}>
                                        {showConfirmPassword ? '👁️' : '👁️‍🗨️'}
                                    </button>
                                </div>
                            </div>
                        </div>

                        <button type="submit" disabled={loading} style={{
                            width: '100%', padding: '14px', marginTop: '8px',
                            background: loading ? '#4338ca' : 'linear-gradient(135deg, #6366f1, #8b5cf6)',
                            color: '#fff', border: 'none', borderRadius: '12px', fontSize: '15px', fontWeight: 600,
                            cursor: loading ? 'wait' : 'pointer', transition: 'all 0.2s',
                        }}>
                            {loading ? 'Creating Account...' : 'Register →'}
                        </button>
                    </form>

                    <div style={{ textAlign: 'center', marginTop: '20px', fontSize: '14px', color: '#64748b' }}>
                        Already have an account?{' '}
                        <a href="/login/student" style={{ color: '#a5b4fc', textDecoration: 'none', fontWeight: 500 }}>Login here</a>
                    </div>
                </div>
            </div>
        </div>
    );
}
